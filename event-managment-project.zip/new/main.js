document.addEventListener("DOMContentLoaded", function () {
    // Utility function to load and display events
    function loadEvents(categoryKey, eventsListId) {
        const events = JSON.parse(localStorage.getItem(categoryKey)) || [];
        const eventsList = document.getElementById(eventsListId);

        if (!eventsList) return; // Exit if the element doesn't exist

        if (events.length === 0) {
            eventsList.innerHTML = "<p>No events found in this category.</p>";
        } else {
            eventsList.innerHTML = ""; // Clear existing content
            events.forEach((event, index) => {
                const eventDiv = document.createElement("div");
                eventDiv.classList.add("event");
                eventDiv.innerHTML = `
                    <h2>${event.name}</h2>
                    <p><strong>Description:</strong> ${event.description}</p>
                    <p><strong>Date:</strong> ${event.date}</p>
                    <p><strong>Time:</strong> ${event.time}</p>
                    <button onclick="deleteEvent(${index}, '${categoryKey}')">Delete Event</button>
                `;
                eventsList.appendChild(eventDiv);
            });
        }
    }

    // Function to delete an event
    window.deleteEvent = function (index, categoryKey) {
        let events = JSON.parse(localStorage.getItem(categoryKey)) || [];
        events.splice(index, 1);
        localStorage.setItem(categoryKey, JSON.stringify(events));
        location.reload(); // Reload page to reflect changes
    };

    // Load events for specific categories
    const pageCategoryMapping = {
        "music.html": "musicEvents",
        "sport.html": "sportsEvents",
        "conference.html": "conferenceEvents",
        "workshop.html": "workshopEvents",
        "other.html": "otherEvents",
    };

    const currentPage = window.location.pathname.split("/").pop();
    const categoryKey = pageCategoryMapping[currentPage];
    if (categoryKey) {
        loadEvents(categoryKey, "events-list");
    }

    // Handle form submission for posting events
    const postEventForm = document.getElementById("post-event-form");
    if (postEventForm) {
        postEventForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const eventName = document.getElementById("event-name").value;
            const eventDescription = document.getElementById("event-description").value;
            const eventDate = document.getElementById("event-date").value;
            const eventTime = document.getElementById("event-time").value;
            const eventCategory = document.getElementById("event-category").value;

            const categoryKey = `${eventCategory.toLowerCase()}Events`;
            let categoryEvents = JSON.parse(localStorage.getItem(categoryKey)) || [];

            categoryEvents.push({
                name: eventName,
                description: eventDescription,
                date: eventDate,
                time: eventTime,
            });

            localStorage.setItem(categoryKey, JSON.stringify(categoryEvents));
            alert("Event posted successfully!");
            window.location.href = `${eventCategory.toLowerCase()}.html`;
        });
    }

    // Handle contact form submission
    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const message = document.getElementById("message").value;

            if (name && email && message) {
                alert(`Thank you, ${name}! Your message has been received. We'll get back to you soon.`);
                contactForm.reset();
            } else {
                alert("Please fill out all fields.");
            }
        });
    }
});
